package br.com.softblue.java.reflection;

public interface Bebida {

	public void preparar();
}
