package br.com.softblue.java.reflection;

public class Cha implements Bebida {

	@Override
	public void preparar() {
		System.out.println("Preparou o ch�");
	}
}
