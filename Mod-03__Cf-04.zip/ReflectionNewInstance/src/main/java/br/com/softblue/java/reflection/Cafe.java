package br.com.softblue.java.reflection;

public class Cafe implements Bebida {

	@Override
	public void preparar() {
		System.out.println("Preparou o caf�");
	}
}
