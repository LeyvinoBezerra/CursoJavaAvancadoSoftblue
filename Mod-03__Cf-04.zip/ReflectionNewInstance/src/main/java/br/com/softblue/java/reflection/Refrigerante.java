package br.com.softblue.java.reflection;

public class Refrigerante implements Bebida {

	@Override
	public void preparar() {
		System.out.println("Preparou o refrigerante");
	}
}
