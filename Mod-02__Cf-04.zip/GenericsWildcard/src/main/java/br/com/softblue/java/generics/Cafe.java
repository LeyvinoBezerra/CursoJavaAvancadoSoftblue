package br.com.softblue.java.generics;

public class Cafe implements Bebida {

	public void preparar() {
		System.out.println("Preparando caf�");
	}
}
