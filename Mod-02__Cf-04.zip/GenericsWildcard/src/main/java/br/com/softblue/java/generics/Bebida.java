package br.com.softblue.java.generics;

public interface Bebida {

	void preparar();
}
