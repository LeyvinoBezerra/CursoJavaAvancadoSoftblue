package br.com.softblue.java.inner;

public class Cha implements Bebida {

	@Override
	public void preparar() {
		System.out.println("Preparando ch�");
	}

}
