package br.com.softblue.java.inner;

public interface Bebida {

	void preparar();
}
