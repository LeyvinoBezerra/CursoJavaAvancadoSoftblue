package br.com.softblue.javaavancado.exercicio;

public class Main {

	public static void main(String[] args) {
		Carro carro = new Carro();
		carro.ligarMotor();
	}
}