package br.com.softblue.java.lambda;

@FunctionalInterface
public interface FactorCalculator {
	double calculate();
}
