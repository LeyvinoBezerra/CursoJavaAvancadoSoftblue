package br.com.softblue.inner;

public class ClasseDeFora {
	public static class ClasseDeDentro {
		private int x = 10;
		
		public void imprimir() {
			System.out.println(x);
		}
	}
}
