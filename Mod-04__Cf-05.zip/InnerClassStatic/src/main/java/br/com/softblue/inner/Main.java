package br.com.softblue.inner;

public class Main {

	public static void main(String[] args) {
		
		ClasseDeFora.ClasseDeDentro c = new ClasseDeFora.ClasseDeDentro();
		c.imprimir();
	}
}
